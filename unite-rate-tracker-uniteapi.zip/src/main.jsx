import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { motion } from "framer-motion";
import {
  AlertTriangle,
  CalendarDays,
  CheckCircle2,
  Clock3,
  Database,
  Gamepad2,
  RefreshCw,
  Search,
  Settings,
  TrendingDown,
  TrendingUp,
  WifiOff,
} from "lucide-react";
import "./style.css";

/*
  Pokémon UNITE Rate Tracker
  UniteAPI取得処理差し替え済み版

  重要:
  - /api/unite で UniteAPIのプレイヤーページを取得・解析します。
  - Vercelにデプロイすると api/unite.js が動きます。
  - ローカルの Vite dev だけだと /api/unite は動かない場合があります。
    その場合は Vercelに上げて確認するのが一番ラクです。

  入力欄には UniteAPIの「/en/p/数字ID」かURLを入れるのがおすすめ。
  例:
  13571372525779122715
  https://uniteapi.dev/en/p/13571372525779122715
*/

const STORAGE_KEY = "unite-rate-tracker-v2";
const DEFAULT_INTERVAL_MINUTES = 3;

const SAMPLE_MATCHES = [
  { id: "2026-05-27-001", date: "2026-05-27", time: "00:18", pokemon: "アブソル", result: "lose", diff: -8, rating: 1544, source: "sample" },
  { id: "2026-05-27-002", date: "2026-05-27", time: "00:35", pokemon: "ゾロアーク", result: "win", diff: 10, rating: 1554, source: "sample" },
  { id: "2026-05-26-001", date: "2026-05-26", time: "15:12", pokemon: "ゾロアーク", result: "win", diff: 9, rating: 1551, source: "sample" },
  { id: "2026-05-26-002", date: "2026-05-26", time: "15:28", pokemon: "ブラッキー", result: "lose", diff: -7, rating: 1544, source: "sample" },
  { id: "2026-05-26-003", date: "2026-05-26", time: "15:46", pokemon: "リーフィア", result: "win", diff: 8, rating: 1552, source: "sample" },
];

function formatDateJP(dateString) {
  const date = new Date(dateString + "T00:00:00");
  return `${date.getMonth() + 1}月${date.getDate()}日`;
}

function signed(value) {
  const num = Number(value);
  return num > 0 ? `+${num}` : `${num}`;
}

function resultLabel(result) {
  if (result === "win") return "勝利";
  if (result === "lose") return "敗北";
  return "不明";
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function saveState(state) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function buildDailyGroups(matches) {
  const sorted = [...matches].sort((a, b) =>
    `${b.date} ${b.time}`.localeCompare(`${a.date} ${a.time}`)
  );

  const byDate = sorted.reduce((acc, match) => {
    if (!acc[match.date]) acc[match.date] = [];
    acc[match.date].push(match);
    return acc;
  }, {});

  return Object.entries(byDate)
    .map(([date, dayMatches]) => {
      const chronological = [...dayMatches].sort((a, b) => a.time.localeCompare(b.time));
      const last = chronological[chronological.length - 1];
      const totalDiff = chronological.reduce((sum, m) => sum + Number(m.diff || 0), 0);
      const finalRating = Number(last.rating || 0);
      const startRating = finalRating - totalDiff;
      const wins = chronological.filter((m) => m.result === "win").length;
      const losses = chronological.filter((m) => m.result === "lose").length;
      return { date, matches: chronological, startRating, finalRating, totalDiff, wins, losses };
    })
    .sort((a, b) => b.date.localeCompare(a.date));
}

function buildPokemonStats(matches) {
  const map = new Map();

  for (const m of matches) {
    if (!map.has(m.pokemon)) {
      map.set(m.pokemon, {
        pokemon: m.pokemon,
        games: 0,
        wins: 0,
        losses: 0,
        totalDiff: 0,
        best: -Infinity,
        worst: Infinity,
      });
    }

    const s = map.get(m.pokemon);
    s.games += 1;
    s.wins += m.result === "win" ? 1 : 0;
    s.losses += m.result === "lose" ? 1 : 0;
    s.totalDiff += Number(m.diff || 0);
    s.best = Math.max(s.best, Number(m.diff || 0));
    s.worst = Math.min(s.worst, Number(m.diff || 0));
  }

  return Array.from(map.values())
    .map((s) => ({
      ...s,
      winRate: Math.round((s.wins / s.games) * 100),
      avgDiff: s.totalDiff / s.games,
    }))
    .sort((a, b) => b.totalDiff - a.totalDiff);
}

function latestFinalRating(matches) {
  const groups = buildDailyGroups(matches);
  return groups[0]?.finalRating || null;
}

async function fetchUniteApiData({ playerId }) {
  if (!playerId.trim()) throw new Error("プレイヤーIDかUniteAPIページURLを入力してください。");

  const res = await fetch(`/api/unite?player=${encodeURIComponent(playerId.trim())}`);
  const data = await res.json().catch(() => null);

  if (!res.ok || !data?.ok) {
    throw new Error(data?.error || `取得失敗: ${res.status}`);
  }

  if (!data.currentRating) {
    throw new Error("現在レートを取得できませんでした。Master/Legend以外だとMPが無い可能性があります。");
  }

  return data;
}

function apiDataToMatch(apiData, previousRating, previousLatestMatchId) {
  const currentRating = Number(apiData.currentRating);
  const latestMatch = apiData.latestMatch;

  if (!latestMatch) {
    return {
      id: `rating-${apiData.fetchedAt || Date.now()}`,
      date: new Date().toISOString().slice(0, 10),
      time: new Date().toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit", hour12: false }),
      pokemon: "不明",
      result: "unknown",
      diff: previousRating == null ? 0 : currentRating - previousRating,
      rating: currentRating,
      source: "uniteapi",
      note: "試合履歴なし。現在レートのみ更新。",
    };
  }

  const diff = previousRating == null ? 0 : currentRating - previousRating;

  return {
    id: latestMatch.id || `match-${apiData.fetchedAt || Date.now()}`,
    date: latestMatch.date,
    time: latestMatch.time,
    pokemon: latestMatch.pokemon || "不明",
    result: latestMatch.result || "unknown",
    diff,
    rating: currentRating,
    source: "uniteapi",
    note: latestMatch.timeAgo ? `UniteAPI表示: ${latestMatch.timeAgo}` : "",
    duplicateOfPrevious: previousLatestMatchId && previousLatestMatchId === latestMatch.id,
  };
}

function StatusIcon({ type }) {
  if (type === "error") return <AlertTriangle size={16} />;
  if (type === "success") return <CheckCircle2 size={16} />;
  return <Clock3 size={16} />;
}

function App() {
  const saved = loadState();

  const [playerId, setPlayerId] = useState(saved?.playerId || "");
  const [matches, setMatches] = useState(saved?.matches || SAMPLE_MATCHES);
  const [activeTab, setActiveTab] = useState("daily");
  const [autoUpdate, setAutoUpdate] = useState(saved?.autoUpdate ?? true);
  const [isFetching, setIsFetching] = useState(false);
  const [lastSeenMatchId, setLastSeenMatchId] = useState(saved?.lastSeenMatchId || null);
  const [status, setStatus] = useState({
    type: "idle",
    message: "プレイヤーIDかUniteAPIページURLを入れて、更新チェックを押してください。",
    lastChecked: saved?.lastChecked || null,
  });

  const dailyGroups = useMemo(() => buildDailyGroups(matches), [matches]);
  const pokemonStats = useMemo(() => buildPokemonStats(matches), [matches]);
  const currentRating = dailyGroups[0]?.finalRating || 0;
  const todayDiff = dailyGroups[0]?.totalDiff || 0;
  const totalWins = matches.filter((m) => m.result === "win").length;
  const totalLosses = matches.filter((m) => m.result === "lose").length;

  useEffect(() => {
    saveState({ playerId, matches, autoUpdate, lastChecked: status.lastChecked, lastSeenMatchId });
  }, [playerId, matches, autoUpdate, status.lastChecked, lastSeenMatchId]);

  async function checkForUpdate() {
    if (isFetching) return;

    setIsFetching(true);
    setStatus((s) => ({ ...s, type: "loading", message: "UniteAPIを確認中..." }));

    try {
      const previousRating = latestFinalRating(matches);
      const apiData = await fetchUniteApiData({ playerId });
      const newMatch = apiDataToMatch(apiData, previousRating, lastSeenMatchId);

      const checked = new Date().toLocaleString("ja-JP", { hour12: false });

      if (newMatch.duplicateOfPrevious) {
        setStatus({
          type: "success",
          message: `新しい試合はありません。現在レート ${apiData.currentRating}`,
          lastChecked: checked,
        });
        return;
      }

      // レート差分が0で、同じ最新試合IDなら保存しない
      if (lastSeenMatchId && newMatch.id === lastSeenMatchId) {
        setStatus({
          type: "success",
          message: `新しい試合はありません。現在レート ${apiData.currentRating}`,
          lastChecked: checked,
        });
        return;
      }

      setMatches((prev) => {
        if (prev.some((m) => m.id === newMatch.id)) return prev;
        return [...prev, newMatch];
      });

      setLastSeenMatchId(newMatch.id);

      setStatus({
        type: "success",
        message: `記録: ${newMatch.time} ${newMatch.pokemon} ${resultLabel(newMatch.result)} ${signed(newMatch.diff)} / レート ${newMatch.rating}`,
        lastChecked: checked,
      });
    } catch (e) {
      const checked = new Date().toLocaleString("ja-JP", { hour12: false });
      setStatus({
        type: "error",
        message: e.message || "取得に失敗しました",
        lastChecked: checked,
      });
    } finally {
      setIsFetching(false);
    }
  }

  useEffect(() => {
    if (!autoUpdate) return;
    const id = window.setInterval(checkForUpdate, DEFAULT_INTERVAL_MINUTES * 60 * 1000);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoUpdate, matches, playerId, isFetching, lastSeenMatchId]);

  function resetSample() {
    setMatches(SAMPLE_MATCHES);
    setLastSeenMatchId(null);
    setStatus({ type: "idle", message: "サンプルデータに戻しました", lastChecked: null });
  }

  function clearData() {
    setMatches([]);
    setLastSeenMatchId(null);
    setStatus({ type: "idle", message: "記録を空にしました", lastChecked: null });
  }

  return (
    <div className="app">
      <div className="container">
        <motion.header initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="hero">
          <div>
            <div className="subTitle"><Gamepad2 size={18} /> Pokémon UNITE Rate Tracker</div>
            <h1>ユナイト レート変動記録</h1>
            <p>UniteAPIのプレイヤーページを確認して、試合ごとのレート差分を保存します。</p>
          </div>

          <div className="heroButtons">
            <button className={autoUpdate ? "button success" : "button muted"} onClick={() => setAutoUpdate((v) => !v)}>
              {autoUpdate ? <CheckCircle2 size={16} /> : <WifiOff size={16} />} 自動更新 {autoUpdate ? "ON" : "OFF"}
            </button>
            <button className="button light" onClick={checkForUpdate} disabled={isFetching}>
              <RefreshCw size={16} className={isFetching ? "spin" : ""} /> 更新チェック
            </button>
          </div>
        </motion.header>

        <section className="statsGrid">
          <div className="card"><span>現在レート</span><strong>{currentRating || "-"}</strong></div>
          <div className="card"><span>今日の増減</span><strong className={todayDiff >= 0 ? "plusText" : "minusText"}>{signed(todayDiff)}</strong></div>
          <div className="card"><span>総合勝敗</span><strong>{totalWins}勝{totalLosses}敗</strong></div>
          <div className="card"><span>更新間隔</span><strong>{DEFAULT_INTERVAL_MINUTES}分</strong></div>
        </section>

        <section className="panel">
          <div className="controlRow">
            <div className="searchBox">
              <Search size={17} />
              <input
                value={playerId}
                onChange={(e) => setPlayerId(e.target.value)}
                placeholder="UniteAPIの数字ID or URL 例: https://uniteapi.dev/en/p/1357..."
              />
            </div>

            <div className="tabs">
              <button className={activeTab === "daily" ? "active" : ""} onClick={() => setActiveTab("daily")}>日別履歴</button>
              <button className={activeTab === "pokemon" ? "active" : ""} onClick={() => setActiveTab("pokemon")}>キャラ別</button>
              <button className={activeTab === "settings" ? "active" : ""} onClick={() => setActiveTab("settings")}>設定</button>
            </div>
          </div>

          <div className={`status ${status.type}`}>
            <StatusIcon type={status.type} />
            <span>{status.message}</span>
            {status.lastChecked && <em>最終確認: {status.lastChecked}</em>}
          </div>
        </section>

        {activeTab === "daily" && (
          <section className="days">
            {dailyGroups.length === 0 && <div className="empty">まだ記録がありません。</div>}

            {dailyGroups.map((day) => (
              <motion.div key={day.date} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="dayCard">
                <div className="dayHeader">
                  <h2><CalendarDays size={20} /> {formatDateJP(day.date)}</h2>
                  <div className="badges">
                    <span>開始 {day.startRating}</span>
                    <span>最終 {day.finalRating}</span>
                    <b className={day.totalDiff >= 0 ? "plus" : "minus"}>{signed(day.totalDiff)}</b>
                    <span>{day.wins}勝{day.losses}敗</span>
                  </div>
                </div>

                <div className="matchList">
                  {day.matches.map((m) => (
                    <div className="match" key={m.id}>
                      <div className="matchLeft">
                        <div className={m.diff >= 0 ? "icon plusIcon" : "icon minusIcon"}>
                          {m.diff >= 0 ? <TrendingUp size={20} /> : <TrendingDown size={20} />}
                        </div>
                        <div>
                          <strong>{m.time}　{m.pokemon}</strong>
                          <p>{resultLabel(m.result)} / レート {m.rating} / {m.source === "sample" ? "サンプル" : "UniteAPI"} {m.note ? ` / ${m.note}` : ""}</p>
                        </div>
                      </div>
                      <div className={m.diff >= 0 ? "diff plus" : "diff minus"}>{signed(m.diff)}</div>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </section>
        )}

        {activeTab === "pokemon" && (
          <section className="pokemonGrid">
            {pokemonStats.map((s) => (
              <div className="pokemonCard" key={s.pokemon}>
                <div className="pokemonTop">
                  <div>
                    <h3>{s.pokemon}</h3>
                    <p>{s.games}試合 / {s.wins}勝{s.losses}敗 / 勝率{s.winRate}%</p>
                  </div>
                  <strong className={s.totalDiff >= 0 ? "total plus" : "total minus"}>{signed(s.totalDiff)}</strong>
                </div>

                <div className="miniStats">
                  <div><span>平均</span><b>{signed(s.avgDiff.toFixed(1))}</b></div>
                  <div><span>最大+</span><b className="plusText">{signed(s.best)}</b></div>
                  <div><span>最大-</span><b className="minusText">{signed(s.worst)}</b></div>
                </div>
              </div>
            ))}
          </section>
        )}

        {activeTab === "settings" && (
          <section className="settingsGrid">
            <div className="settingCard">
              <h3><Database size={18} /> 保存</h3>
              <p>今はブラウザのlocalStorageに保存。スマホを変えても残したいならSupabase/Firebaseに変更する。</p>
              <div className="settingButtons">
                <button onClick={resetSample}>サンプルに戻す</button>
                <button className="danger" onClick={clearData}>記録を空にする</button>
              </div>
            </div>

            <div className="settingCard">
              <h3><RefreshCw size={18} /> 自動更新</h3>
              <p>1人専用なら3分おき。UniteAPIの更新後、次回チェックで反映されます。</p>
              <strong>{DEFAULT_INTERVAL_MINUTES}分おき</strong>
            </div>

            <div className="settingCard wide">
              <h3><Settings size={18} /> 注意点</h3>
              <p>
                UniteAPIの公開HTMLを解析する方式です。UniteAPI側のページ構造が変わると、キャラ名や勝敗の取得がズレる可能性があります。
                レート増減は「前回保存したレート → 今回取得したレート」の差分です。
              </p>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
