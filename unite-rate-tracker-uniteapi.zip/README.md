# Unite Rate Tracker - UniteAPI取得処理入り版

Pokémon UNITE のレート変動を記録するための1人専用サイトです。

## 今回の版で入っているもの

- React/Viteフロント
- Vercel Serverless Function `/api/unite`
- UniteAPIのプレイヤーページHTMLを取得・解析
- 現在MPを取得
- 最新試合らしき情報を取得
- 前回保存レートとの差分で `+○ / -○` を記録
- 3分おき自動更新
- 手動更新
- 日別履歴
- キャラ別集計
- localStorage保存

## 重要

UniteAPIの正式な公開API仕様が確認できないため、これは「公開プレイヤーページのHTMLを解析する方式」です。

そのため、UniteAPI側のHTML構造が変わると壊れる可能性があります。

## 入力欄に入れるもの

おすすめは UniteAPI のプレイヤーページURL、または `/en/p/` の後ろの数字IDです。

例:

```text
https://uniteapi.dev/en/p/13571372525779122715
```

または

```text
13571372525779122715
```

## デプロイ方法

### Vercel推奨

このフォルダをGitHubにアップロードして、VercelでImportします。

Vercelなら `api/unite.js` がそのまま `/api/unite` として動きます。

## ローカルでの注意

`npm run dev` はViteだけなので、環境によっては `/api/unite` が動きません。

本番確認はVercelに上げるのが一番ラクです。

## 起動

```bash
npm install
npm run dev
```
