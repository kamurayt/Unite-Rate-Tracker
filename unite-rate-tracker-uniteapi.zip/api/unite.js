/*
  Vercel Serverless Function
  /api/unite?player=UNITEAPI_PLAYER_PAGE_ID_OR_URL

  使い方:
  - Vercelにデプロイすると /api/unite が動きます。
  - player は UniteAPI のプレイヤーページURL、または /en/p/ の後ろの数字IDがおすすめ。
    例: 13571372525779122715
    例: https://uniteapi.dev/en/p/13571372525779122715

  注意:
  UniteAPIの公開ページHTMLを解析する方式です。
  UniteAPI側のHTML構造が変わると壊れる可能性があります。
*/

function decodeHtml(input = "") {
  return input
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

function htmlToText(html = "") {
  return decodeHtml(
    html
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
      .replace(/alt="([^"]*)"/gi, " Image: $1 ")
      .replace(/aria-label="([^"]*)"/gi, " $1 ")
      .replace(/<[^>]+>/g, " ")
  );
}

function resolvePlayerUrl(player) {
  const value = String(player || "").trim();
  if (!value) throw new Error("player が空です");

  if (/^https?:\/\//i.test(value)) return value;

  const numeric = value.match(/\d{10,}/);
  if (numeric) return `https://uniteapi.dev/en/p/${numeric[0]}`;

  // 古いUniteAPIは https://uniteapi.dev/名前 や /コード で開けることがあるため保険
  const cleaned = value.replace(/^#/, "");
  return `https://uniteapi.dev/${encodeURIComponent(cleaned)}`;
}

function parseCurrentRating(text) {
  // 例: "35 x Master 225 MP" / "Legend 1,238 MP" / "Master 709 MP"
  const mpPatterns = [
    /(?:Legend|Master)\s+(?:\d+\s*x\s*Master\s+)?([\d,]+)\s*MP/i,
    /(?:\d+\s*x\s*Master\s+)([\d,]+)\s*MP/i,
    /([\d,]+)\s*MP/i,
  ];

  for (const pattern of mpPatterns) {
    const m = text.match(pattern);
    if (m) return Number(m[1].replace(/,/g, ""));
  }

  return null;
}

function parsePlayerName(text) {
  // title付近や ID の直前をゆるく見る
  const m = text.match(/Counters\s+(.{1,40}?)\s+ID:\s*#/i) || text.match(/Privacy Policy\s+(.{1,40}?)\s+ID:\s*#/i);
  if (m) return m[1].trim();
  return null;
}

function parseLatestMatch(text) {
  if (/No Match History|No recent matches/i.test(text)) return null;

  // 例:
  // "22 days ago Theia Sky Ruins (Kyogre) Solo Image: Talonflame 15 ..."
  // "3 months ago Theia Sky Ruins (Groudon) Duo Image: Talonflame 15 ..."
  const timeAgoMatch = text.match(/(\d+\s+(?:seconds?|minutes?|hours?|days?|weeks?|months?)\s+ago)\s+(.{0,80}?)(Solo|Duo|Trio|Squad|5 Stack|Standard|Ranked)/i);
  const timeAgo = timeAgoMatch ? timeAgoMatch[1] : null;
  const mode = timeAgoMatch ? timeAgoMatch[3] : null;

  const startIndex = timeAgoMatch ? text.indexOf(timeAgoMatch[0]) : -1;
  const matchSlice = startIndex >= 0 ? text.slice(startIndex, startIndex + 700) : text.slice(-1000);

  // Latest match中の最初の Image: Pokémon名 を使用キャラ候補にする
  // Avatar系やアイテムを避けるため、よく出るポケモン名は広めに許容
  const imageMatches = [...matchSlice.matchAll(/Image:\s*([A-Za-zÀ-ÿ'’.\- ]{2,30}|[\u3040-\u30ff\u3400-\u9fffー]{2,30})/g)]
    .map((m) => m[1].trim())
    .filter((name) => !/Avatar|Favorite|Master|Legend|Beginner|Great|Expert|Veteran|Ultra|Muscle Band|Eject Button|Rapid|Scarf|Weight|Lens|Policy|Share|Spoon|Incense|Bell|Stone|Razor|Choice|Full Heal|X Speed|Potion|Button/i.test(name));

  const pokemon = imageMatches[0] || "不明";

  const scoreMatch = matchSlice.match(/(\d{2,4})\s+vs\s+(\d{2,4})/i);
  let result = "unknown";
  if (scoreMatch) {
    const a = Number(scoreMatch[1]);
    const b = Number(scoreMatch[2]);
    if (a > b) result = "win";
    if (a < b) result = "lose";
  }

  // HTML上に絶対時刻が無い場合があるので、取得時刻を使う
  const now = new Date();
  const date = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  const time = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;

  const idBase = `${timeAgo || "latest"}-${pokemon}-${scoreMatch ? scoreMatch[0] : ""}-${mode || ""}`;
  const id = Buffer.from(idBase).toString("base64").replace(/[^a-zA-Z0-9]/g, "").slice(0, 40);

  return {
    id: id || `latest-${Date.now()}`,
    date,
    time,
    pokemon,
    result,
    timeAgo,
    mode,
    rawSnippet: matchSlice.slice(0, 300),
  };
}

export default async function handler(req, res) {
  try {
    const player = req.query.player;
    const url = resolvePlayerUrl(player);

    const response = await fetch(url, {
      headers: {
        "user-agent": "Mozilla/5.0 UniteRateTracker/1.0",
        "accept": "text/html,application/xhtml+xml",
      },
    });

    if (!response.ok) {
      return res.status(response.status).json({
        ok: false,
        error: `UniteAPI page fetch failed: ${response.status}`,
        url,
      });
    }

    const html = await response.text();
    const text = htmlToText(html);
    const currentRating = parseCurrentRating(text);
    const latestMatch = parseLatestMatch(text);
    const playerName = parsePlayerName(text);

    if (!currentRating) {
      return res.status(422).json({
        ok: false,
        error: "現在レート(MP)をページから読み取れませんでした。Master/Legend以外、またはHTML構造変更の可能性があります。",
        url,
      });
    }

    return res.status(200).json({
      ok: true,
      url,
      playerName,
      currentRating,
      latestMatch,
      fetchedAt: new Date().toISOString(),
    });
  } catch (error) {
    return res.status(500).json({
      ok: false,
      error: error.message || "unknown error",
    });
  }
}
